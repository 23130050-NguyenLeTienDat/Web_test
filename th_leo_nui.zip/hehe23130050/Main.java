package hehe23130050;

public class Main {
public static void main(String[] args) {
	LocalSearch l = new LocalSearch();
	l.run();
}
}
