package th3;

import java.io.File; // Nhập thư viện File (để kiểm tra thông tin file, như .length() or .exists())
import java.io.FileInputStream; // Nhập thư viện để ĐỌC file (luồng vào)
import java.io.FileOutputStream; // Nhập thư viện để GHI file (luồng ra)
import java.io.IOException; // Nhập thư viện để xử lý các lỗi I/O (Input/Output)

public class SplitAndJoin {
	
	/**
	 * Phương thức dùng để CẮT file.
	 * @param source Đường dẫn đầy đủ đến file gốc (ví dụ: "D:\data.zip").
	 * @param pSize  Kích thước (tính bằng byte) của mỗi file con.
	 * @throws IOException
	 */
	public static void split(String source, long pSize) throws IOException{
		String dest; // Biến tạm để lưu tên file con (ví dụ: "D:\data.zip.001")
		FileOutputStream fos; // Luồng để GHI dữ liệu vào file con
		
		// 1. Mở luồng ĐỌC file gốc (source)
		FileInputStream fis =  new FileInputStream(source);
		
		// 2. Tạo đối tượng File để lấy thông tin (như kích thước)
		File file = new File(source);
		
		// 3. Tính toán số lượng file con
		// Số file con có kích thước ĐẦY ĐỦ (pSize)
		long fileNum = file.length() / pSize ; 
		// Kích thước của file con CUỐI CÙNG (phần còn dư)
		long remain = file.length() % pSize; 
		
		int childNo = 0; // Biến đếm số thứ tự file con (bắt đầu từ 0)
		
		// 4. Tạo vòng lặp để tạo ra các file con có kích thước đầy đủ (fileNum lần)
		for(; childNo < fileNum ; childNo ++) {
			// Tạo tên file con (ví dụ: "D:\data.zip" + ".001")
			dest = source + createExit(childNo);
			// Mở luồng GHI vào file con mới
			fos = new FileOutputStream(dest);
			// Gọi hàm copy để sao chép chính xác pSize byte từ file gốc (fis) sang file con (fos)
			copy(fis, fos, pSize);
			// Đóng file con lại sau khi ghi xong
			fos.close();
		}
		
		// 5. Xử lý phần dư (nếu có)
		if(remain >0) {
			// Tạo tên cho file con cuối cùng
			dest = source + createExit(childNo); // childNo lúc này đang bằng fileNum
			// Mở luồng GHI vào file con cuối cùng
			fos = new FileOutputStream(dest);
			// Tạo bộ đệm 1MB
			byte[] buff = new byte[1024000];
			int count ; // Biến lưu số byte thực sự đọc được
			// Đọc NỐT phần còn lại của file gốc (cho đến khi hết file, read() trả về -1)
			while((count = fis.read(buff)) != -1) {
				// Ghi phần đọc được vào file con cuối cùng
				fos.write(buff,0, count);		
				// Lần 1: Ghi 1MB, đóng file.
				// Lần 2: Đọc 1MB, GHI VÀO FILE
				fos.close();
			}
		}
	}
	
	/**
	 * Hàm phụ trợ để tạo đuôi file con (ví dụ: 0 -> ".001", 10 -> ".010").
	 * (Hàm này thực ra không cần `throws IOException` vì nó không làm I/O).
	 */
	public static String createExit(int childNo) throws IOException{
		childNo ++; // Tăng lên 1 (để bắt đầu từ .001 thay vì .000)
		
		// Chèn số 0 vào trước để đảm bảo tên file theo thứ tự (padding)
		if(childNo < 10) return ".00" + childNo; // 1-9 -> .001, .009
		if(childNo < 100) return ".0" + childNo; // 10-99 -> .010, .099
		return "." + childNo; // 100+ -> .100
	}
	
	/**
	 * Hàm phụ trợ: Sao chép chính xác PSIZE byte từ luồng vào (fis) sang luồng ra (fos).
	 */
	public static void copy(FileInputStream fis, FileOutputStream fos, long pSize) throws IOException{
		byte [] buff = new byte[1024000]; // Bộ đệm 1MB
		int count; // Số byte đọc được thực tế
		long remain = pSize; // Số byte CÒN LẠI cần sao chép (đếm ngược về 0)
		int byteMustRead; // Số byte TỐI ĐA được đọc trong 1 lần
		
		// Lặp cho đến khi sao chép đủ pSize (remain = 0)
		while(remain > 0) {
			// Tính toán số byte sẽ đọc:
			// Chọn số nhỏ hơn giữa Kích thước bộ đệm (1MB) và Số byte còn lại (remain).
			// (Để đảm bảo lần đọc cuối cùng không đọc lố pSize)
			byteMustRead =(int) Math.min(buff.length, remain);
			
			// Đọc dữ liệu từ file gốc vào bộ đệm
			count = fis.read(buff, 0, byteMustRead);
			// Ghi dữ liệu từ bộ đệm ra file con
			fos.write(buff, 0, count);
			// Giảm số byte còn lại
			remain -= count;
		}
	}
	
	/**
	 * Phương thức dùng để GHÉP các file con thành file gốc.
	 * @param source Đường dẫn đến BẤT KỲ file con nào (ví dụ: "D:\data.zip.001" hoặc "D:\data.zip.006").
	 * @throws IOException
	 */
	public static void join(String source) throws IOException{
		String childName; // ⚠️ Biến này được khai báo nhưng không bao giờ được sử dụng.
		
		// 1. Lấy tên file gốc (bằng cách bỏ đuôi .00x)
		// Ví dụ: "D:\data.zip.001" -> "D:\data.zip"
		String org = source.substring(0, source.lastIndexOf("."));
		
		// 2. Mở luồng GHI vào file gốc (file đích)
		FileOutputStream fos = new FileOutputStream(org);
		
		int fileNo = 0; // Biến đếm số thứ tự file con, bắt đầu từ 0
		
		// 3. Vòng lặp vô hạn (sẽ dừng bằng `break` khi không tìm thấy file con)
		while(true) {
			// 4. Tạo tên file con (lần 1: ".001", lần 2: ".002", ...)
			// Dùng `fileNo++` (toán tử hậu tố):
			// - Lần 1: Dùng fileNo = 0 cho createExit (thành .001), SAU ĐÓ tăng fileNo lên 1.
			// - Lần 2: Dùng fileNo = 1 cho createExit (thành .002), SAU ĐÓ tăng fileNo lên 2.
			String pFile = org + createExit(fileNo++);
			
			// 5. Kiểm tra xem file con này có tồn tại không
			File file = new File(pFile);
			if(!file.exists()) break; // Nếu không tồn tại (ví dụ: không có file .007) -> Dừng lặp
			
			// 6. Nếu file tồn tại, mở luồng ĐỌC file con đó
			FileInputStream fis = new FileInputStream(pFile);
			
			// 7. Tạo bộ đệm (100KB)
			byte[] buff = new byte[102400];
			int count;
			
			// 8. Đọc toàn bộ nội dung file con
			while((count = fis.read(buff)) != -1) {
				// 9. Ghi nội dung đó vào file gốc (fos)
				fos.write(buff, 0, count);
			}
			
			// 10. Đóng file con (fis) sau khi đọc xong
			fis.close();
		}
		// 11. Đóng file gốc (fos) sau khi đã ghép xong tất cả
		fos.close();
	}
	
	/**
	 * Hàm main để chạy thử chương trình.
	 */
	public static void main(String[] args) throws IOException {
		// (Typo: 'soure' nên là 'source')
		String soure = "D:\\LTM\\tét\\heh1231.txt\\aa.txt";
		
		// Chạy hàm cắt file: Cắt file "aa.txt" thành các file con 1MB (1024000 byte)
		// 🐞 LƯU Ý: Hàm split() của bạn đang có lỗi (xem chú thích ở trên).
		split(soure, 1024000);
		
		// Chạy hàm ghép file (đang bị vô hiệu hóa)
		// (Truyền tên file con bất kỳ vào là được)
		join("D:\\LTM\\tét\\heh1231.txt\\aa.txt.006");
	}
}