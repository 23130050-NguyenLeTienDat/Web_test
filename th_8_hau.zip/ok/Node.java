package ok;

import java.util.ArrayList;
import java.util.List;

public class Node {
    int n;
    public List<Integer> state; // state: list cÃ¡c vá»‹ trÃ­ hÃ ng cá»§a quÃ¢n háº­u, chá»‰ sá»‘ list lÃ  cá»™t
    public Node parent;
    
    // Constructor Ä‘á»ƒ táº¡o node gá»‘c
    public Node(int n) {
        this.n = n;
        this.state = new ArrayList<>();
        this.parent = null;
    }
    
    // Constructor Ä‘á»ƒ táº¡o cÃ¡c node con
    public Node(int n, List<Integer> state) {
        this.n = n;
        this.state = state;
        this.parent = null;
    }

    /**
     * Chá»‰ cáº§n kiá»ƒm tra quÃ¢n háº­u cuá»‘i cÃ¹ng vá»›i táº¥t cáº£ cÃ¡c quÃ¢n háº­u Ä‘Ã£ Ä‘áº·t trÆ°á»›c Ä‘Ã³.
     */
    public boolean isValid(List<Integer> state) {
        if (state.size() <= 1) {
            return true;
        }
        int lastQueenCol = state.size() - 1;
        int lastQueenRow = state.get(lastQueenCol);

        for (int prevCol = 0; prevCol < lastQueenCol; prevCol++) {
            int prevRow = state.get(prevCol);
            
            // 1. Kiá»ƒm tra cÃ¹ng hÃ ng
            if (lastQueenRow == prevRow) {
                return false;
            }
            
            // 2. Kiá»ƒm tra Ä‘Æ°á»�ng chÃ©o
            if (Math.abs(lastQueenCol - prevCol) == Math.abs(lastQueenRow - prevRow)) {
                return false;
            }
        }
        return true;
    }

    private List<Integer> place(int row) {
        List<Integer> newState = new ArrayList<>(this.state);
        newState.add(row);
        if (isValid(newState)) {
            return newState;
        }
        return null;
    }

    public List<Node> getNeighbours() {
        // Náº¿u Ä‘Ã£ Ä‘áº·t Ä‘á»§ N quÃ¢n háº­u, khÃ´ng cÃ³ tráº¡ng thÃ¡i káº¿ tiáº¿p
        if (state.size() == n) {
            return new ArrayList<>(); //Tráº£ vá»� list rá»—ng
        }

        List<Node> neighbours = new ArrayList<>();
        for (int row = 0; row < n; row++) {
            List<Integer> newState = place(row);
            if (newState != null) {
                Node child = new Node(n, newState);
                neighbours.add(child);
            }
        }
        return neighbours;
    }

}
