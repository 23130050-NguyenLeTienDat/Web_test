package ok;

import ok.Node;

public class Main {
	public static void main(String[] args) {
		Queens q = new Queens(4);
		q.bfs();
		q.dfs();
	}
}
